# Sample Snack app

Trabalho de faculdade, em construção um aplicativo de serviços gerais, onde
o usuário possa buscar serviços que tenha necessidade e os fornecedores
possam oferecer seus serviços.




Terceiro  período 
Curso: Análise e Desenvolvimento de Sistemas
Puc Minas
Outubro/2022


Nome aplicativo: BH Prestação de Serviços.
